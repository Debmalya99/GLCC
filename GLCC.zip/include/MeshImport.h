#ifndef MESH_IMPORT_H
#define MESH_IMPORT_H

#include <assimp/scene.h>
#include <assimp/cimport.h>
#include <assimp/postprocess.h>
#include <iostream>

class MeshImport{   // So I have decided that this class will usually be derived from in real applications
protected:
    std::vector<float> vertex_data;
    std::vector<float> normal_data;
    std::vector<float> texture_coord_data;

    std::vector<unsigned int> element_data;
    
    const aiScene* modelScene;
    aiMesh* modelMesh;
    aiFace* face;

public:
    // No constructor. 
    void _Import(std::string filename,unsigned int __flags);    
    float* getVertices();
    float* getNormals();
    float* getTexcoords();
    unsigned int* getElements();

    unsigned int getNumVertices();
    unsigned int getNumNormals();
    unsigned int getNumElements();
    unsigned int getNumTexcoords();

};

#endif