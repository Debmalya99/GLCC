#ifndef APPLICATION_H
#define APPLICATION_H

class Application {
protected:
  bool m_running;

public:
  void setUp()
  {
    m_running = true;
  }
  virtual void Start()=0; // Purely virtual function that sets up OpenGL context and stuff
  virtual void InitResources() = 0; // Initializes resources
  bool Running()
  {
    return m_running;
  }
  virtual void Update() = 0; // Logic and Stuff goes here
  virtual void handleEvents() = 0; // Mandatory. For event handling loops
  virtual void Render() = 0;
  virtual void SwapBuffers(); // Mandatory. For double buffering stuff define this.( and call this )
  void Quit()
  {
    m_running = false;
  }
  void Run()
  {
    setUp();
    Start();
    InitResources();
    while(Running())
    {
      handleEvents();
      Update();
      Render();
      SwapBuffers();
    }
  }

};

#endif

#define GLCC_APP_MAIN(x) int main(){x a;a.Run();return 0;}
