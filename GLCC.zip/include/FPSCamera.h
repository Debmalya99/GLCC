#ifndef FPS_CAMERA_H
#define FPS_CAMERA_H

#define GLM_FORCE_RADIANS

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

class FPSCamera {
private:
  glm::vec3 position;
  glm::vec3 front;
  glm::vec3 up;

  float speed;

  glm::mat4 view;

public:
  FPSCamera();
  void MoveForward();
  void MoveBackward();
  void MoveLeft();
  void MoveRight();
  glm::mat4 getViewMatrix();


  //virtual ~FPSCamera ();
};

#endif
