#ifndef DRAWABLE_H
#define DRAWABLE_H

#include <glad/glad.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

#define DEG_TO_RAD 0.017453292

class Drawable {
protected:

public:
  virtual void Draw(GLuint shaderID,glm::mat4 MVP_matrix,std::string MVP_name) = 0;
};

#endif
