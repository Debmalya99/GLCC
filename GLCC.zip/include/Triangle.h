#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <glad/glad.h>
#include <iostream>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>


class Triangle {
private:
  GLuint VBO,VAO;
  float* verts;
public:
  Triangle();
  void create_buffers();
  void Draw(GLuint shaderID);
  void Draw(GLuint shaderID,glm::mat4 mvp,std::string MVP_name);
  //virtual ~Triangle ();
};

#endif
