#ifndef TRANS3D_H
#define TRANS3D_H
#define GLM_FORCE_RADIANS
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>

#define DEG_TO_RAD 0.017453292

namespace Trans3D {

class Transformable {
protected:
  glm::mat4 m_model,m_rotation,m_scale,m_translation;
  float X,Y,Z;
public:
  Transformable();
  void setPosition(float x,float y,float z);
  void Move(float dx,float dy,float dz);

  void Scale(float f);
  void Scale(float xf,float yf,float zf); // Sets Relative scale
  void setScale(float xf,float yf,float zf);
  void setScale(float f); // Sets absolute scale

  void Rotate(float axisX,float axisY,float axisZ,float angle);
  void setRotation(float axisX,float axisY,float axisZ,float angle);
  void XRotate(float angle);
  void YRotate(float angle);
  void ZRotate(float angle);

  glm::vec3 getPosition();

  float* getTransformPtr(); // Returns the pointer to the first element of the model matrix m_model
  glm::mat4 getMatrix();  // Returns the glm::mat4 m_model
  //~Transformable ();
};

/*class Camera : public Transformable {
protected:
  glm::mat4 m_view,m_proj;

public:
  Camera ();
  void LookAt(glm::vec3,glm::vec3);
  glm::mat4 getViewMatrix();
  void setUpPerspective(float fov,float aspect_ratio,float near_clip_distance,float far_clip_distance);
  glm::mat4 getProjectionMatrix();
  //virtual ~Camera ();
};*/

} /* Trans3D */

#endif
