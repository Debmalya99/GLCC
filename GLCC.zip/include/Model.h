#ifndef MODEL_H
#define MODEL_H

#include <glad/glad.h>
#include <MeshImport.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <SFML/Graphics.hpp>

class Model:public MeshImport {
private:
  GLuint VBO_vert,VBO_tex,VBO_norm,IBO,VAO;
  sf::Texture texture;
public:
  void Import(std::string filename);
  void ImportTexture(std::string filename);
  void create_buffers();
  void Draw(GLuint shaderID,glm::mat4 mvp,std::string MVP_id);
};

#endif
