#include <Trans3D.h>

using namespace Trans3D;

Transformable::Transformable()
{
  m_model = glm::mat4(1.0f);
  m_translation = glm::mat4(1.0f);
  m_scale = glm::mat4(1.0f);
  m_rotation = glm::mat4(1.0f);
  X = 0;
  Y = 0;
  Z = 0;
}

void Transformable::setPosition(float x,float y,float z)
{
  m_translation = glm::mat4(1.0f);
  m_translation = glm::translate(m_translation,glm::vec3(x,y,z));
  X = x;
  Y = y;
  Z = z;
}
void Transformable::Move(float dx,float dy,float dz)
{

  setPosition(X+dx,Y+dy,Z+dz);
  X = X+dx;
  Y = Y+dy;
  Z = Z+dz;
}
void Transformable::Scale(float f)
{
 m_scale = glm::scale(m_scale,glm::vec3(f));
}

void Transformable::Scale(float xf,float yf,float zf)
{
  m_scale = glm::scale(m_scale,glm::vec3(xf,yf,zf));
}
void Transformable::setScale(float f)
{
    m_scale = glm::scale(glm::mat4(1.0f),glm::vec3(f));
}
void Transformable::setScale(float xf,float yf,float zf)
{
  m_scale = glm::scale(glm::mat4(1.0f),glm::vec3(xf,yf,zf));
}


void Transformable::Rotate(float axisX,float axisY,float axisZ,float angle)
{
  m_rotation = glm::rotate(m_rotation,angle,glm::vec3(axisX,axisY,axisZ));
}

void Transformable::setRotation(float axisX,float axisY,float axisZ,float angle)
{
  m_rotation = glm::rotate(glm::mat4(1.0f),angle,glm::vec3(axisX,axisY,axisZ));
}

void Transformable::XRotate(float angle)
{
  m_rotation = glm::rotate(m_rotation,angle,glm::vec3(1,0,0));
}


void Transformable::YRotate(float angle)
{
  m_rotation = glm::rotate(m_rotation,angle,glm::vec3(0,1,0));
}


void Transformable::ZRotate(float angle)
{
  m_rotation = glm::rotate(m_rotation,angle,glm::vec3(0,0,1));
}

glm::mat4 Transformable::getMatrix()
{
  m_model = m_translation*m_rotation*m_scale;
  return m_model;
}

float* Transformable::getTransformPtr()
{
  m_model = m_translation*m_rotation*m_scale;
  return &m_model[0][0];
}
glm::vec3 Transformable::getPosition()
{
  return glm::vec3(X,Y,Z);
}




/*Camera::Camera()
{
  m_view = glm::mat4(1.0f);
  m_translation = glm::mat4(1.0f);
  m_scale = glm::mat4(1.0f);
  m_rotation = glm::mat4(1.0f);
  m_proj = glm::mat4(1.0f);

  X = 0;
  Y = 0;
  Z = 0;
}

void Camera::LookAt(glm::vec3 target,glm::vec3 up)
{
  m_view = glm::lookAt(
    getPosition(), // Camera is at glm::vec3(X,Y,Z)
    target, // and looks at the target
    up  // Head is up
    );
}

glm::mat4 Camera::getViewMatrix()
{
  
  return m_view;
}

void Camera::setUpPerspective(float fov,float aspect_ratio,float near_clip_distance,float far_clip_distance)
{
  // FOV is in radians
  m_proj = glm::perspective(fov,aspect_ratio,near_clip_distance,far_clip_distance);
}
glm::mat4 Camera::getProjectionMatrix()
{
  return m_proj;
}
*/
