#include <Triangle.h>

Triangle::Triangle()
{
  static float vertices[] =
  {
    -0.5f, -0.5f, 0.0f,
    0.5f, -0.5f, 0.0f,
    0.0f,  0.5f, 0.0f
  };
  verts = vertices;
}
void Triangle::create_buffers()
{
  glGenVertexArrays(1,&VAO);
  glGenBuffers(1,&VBO);
  glBindVertexArray(VAO);

  glBindBuffer(GL_ARRAY_BUFFER,VBO);
  glBufferData(GL_ARRAY_BUFFER,9*sizeof(float),verts,GL_STATIC_DRAW);

  //glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
  glEnableVertexAttribArray(0);

  glBindBuffer(GL_ARRAY_BUFFER,0);
  glBindVertexArray(0);
}

void Triangle::Draw(GLuint shaderID)
{
  glUseProgram(shaderID);
  glBindVertexArray(VAO);
  glDrawArrays(GL_TRIANGLES,0,3);
  glBindVertexArray(0);
}

void Triangle::Draw(GLuint shaderID,glm::mat4 mvp,std::string MVP_name)
{
  GLuint ID = glGetUniformLocation(shaderID,MVP_name.c_str());
  glUseProgram(shaderID);
  glUniformMatrix4fv(ID,1,GL_FALSE,&mvp[0][0]);
  glBindVertexArray(VAO);
  glDrawArrays(GL_TRIANGLES,0,3);
  glBindVertexArray(0);
}
