#include <FPSCamera.h>

FPSCamera::FPSCamera()
{
  speed += 0.05f;

  position   = glm::vec3(0.0f, 0.0f,  3.0f);
  front = glm::vec3(0.0f, 0.0f, -1.0f);
  up    = glm::vec3(0.0f, 1.0f,  0.0f);

  //view = glm::lookAt(position, position + front, up);
  view = glm::lookAt(glm::vec3(4,3,3),glm::vec3(0,0,0),glm::vec3(0,1,0));

}

void FPSCamera::MoveForward()
{
  position += speed*front;
}
void FPSCamera::MoveBackward()
{
  position -= speed*front;
}
void FPSCamera::MoveLeft()
{
  position -= glm::normalize(glm::cross(front,up))*speed;
}
void FPSCamera::MoveRight()
{
  position += glm::normalize(glm::cross(front,up))*speed;
}

glm::mat4 FPSCamera::getViewMatrix()
{
  view = glm::lookAt(position,position+front,up);
  return view;
}
