#include <Model.h>

void Model::Import(std::string filename)
{
  _Import(filename,aiProcess_Triangulate|aiProcess_FlipUVs);
}
void Model::create_buffers()
{
  glGenVertexArrays(1,&VAO);
  glGenBuffers(1,&VBO_vert);
  glGenBuffers(1,&VBO_tex);
  glGenBuffers(1,&VBO_norm);
  glGenBuffers(1,&IBO);

  glBindVertexArray(VAO);

  glBindBuffer(GL_ARRAY_BUFFER,VBO_vert);
  glBufferData(GL_ARRAY_BUFFER,sizeof(float)*getNumVertices(),getVertices(),GL_STATIC_DRAW);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);

  glBindBuffer(GL_ARRAY_BUFFER,VBO_tex);
  glBufferData(GL_ARRAY_BUFFER,sizeof(float)*getNumTexcoords(),getTexcoords(),GL_STATIC_DRAW);
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,0,0);

  glBindBuffer(GL_ARRAY_BUFFER,VBO_norm);
  glBufferData(GL_ARRAY_BUFFER,sizeof(float)*getNumNormals(),getNormals(),GL_STATIC_DRAW);
  glEnableVertexAttribArray(2);
  glVertexAttribPointer(2,3,GL_FLOAT,GL_FALSE,0,0);

  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,IBO);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(unsigned int)*getNumElements(),getElements(),GL_STATIC_DRAW);

  glBindVertexArray(0);
  glBindBuffer(GL_ARRAY_BUFFER,0);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
}

  void Model::Draw(GLuint shaderID,glm::mat4 mvp,std::string MVP_id)
  {
    glUseProgram(shaderID);

    sf::Texture::bind(&texture);

    GLuint mvp_id = glGetUniformLocation(shaderID,MVP_id.c_str());
    glUniformMatrix4fv(mvp_id,1,GL_FALSE,&mvp[0][0]);
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES,getNumElements(),GL_UNSIGNED_INT,0);
    glBindVertexArray(0);
    sf::Texture::bind(NULL);
  }

  void Model::ImportTexture(std::string filename)
  {
    texture.loadFromFile(filename);
  }
