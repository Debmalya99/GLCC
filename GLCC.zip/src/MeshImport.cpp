#include <MeshImport.h>

void MeshImport::_Import(std::string filename,unsigned int __flags)
{
    vertex_data.clear();
    normal_data.clear();
    texture_coord_data.clear();
    element_data.clear();


    modelScene = aiImportFile(filename.c_str(),__flags);

    modelMesh = modelScene->mMeshes[0]; // Recommended to keep just one object per file
    for(unsigned int v = 0;v<modelMesh->mNumVertices;v++)
    {
        vertex_data.push_back(modelMesh->mVertices[v].x);
        vertex_data.push_back(modelMesh->mVertices[v].y);
        vertex_data.push_back(modelMesh->mVertices[v].z);
    
        normal_data.push_back(modelMesh->mNormals[v].x);
        normal_data.push_back(modelMesh->mNormals[v].y);
        normal_data.push_back(modelMesh->mNormals[v].z);
    
    if(modelMesh->HasTextureCoords(0))
    {
        texture_coord_data.push_back(modelMesh->mTextureCoords[0][v].x);
        texture_coord_data.push_back(modelMesh->mTextureCoords[0][v].y);
    }
    else
    {
        texture_coord_data.push_back(0);
        texture_coord_data.push_back(0);   
    }
    
    }
    
    for(unsigned int i = 0; i < modelMesh->mNumFaces; i++)
    {
        face = &modelMesh->mFaces[i];
        element_data.push_back(face->mIndices[0]);
        element_data.push_back(face->mIndices[1]);
        element_data.push_back(face->mIndices[2]);
    }
    
}

float* MeshImport::getVertices()
{
    return &vertex_data[0];
}
float* MeshImport::getNormals()
{
    return &normal_data[0];
}
float* MeshImport::getTexcoords()
{
    return &texture_coord_data[0];
}
unsigned int* MeshImport::getElements()
{
    return &element_data[0];
}
unsigned int MeshImport::getNumVertices()
{
    return vertex_data.size();
}
unsigned int MeshImport::getNumNormals()
{
    return normal_data.size();
}
unsigned int MeshImport::getNumElements()
{
    return element_data.size();
}
unsigned int MeshImport::getNumTexcoords()
{
    return texture_coord_data.size();
}